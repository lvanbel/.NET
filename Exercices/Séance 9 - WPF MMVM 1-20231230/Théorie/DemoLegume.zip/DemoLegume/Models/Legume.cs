﻿using System;
using System.Collections.Generic;

namespace DemoLegume.Models
{
    public partial class Legume
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
